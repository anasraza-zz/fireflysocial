let firefly;
let flyCount;


let dataServer;
let pubKey = "pub-c-a89113e6-3093-4b43-8f4a-e1dce36bb107";
let subKey = "sub-c-7f74413c-3b65-11ec-8182-fea14ba1eb2b";
let channelName = "fireflySocial";

let publishedFlyCount = 0;

function preload() {   
    firefly = loadImage('assets/firefly.png');
    }

  
  
  function setup() {
    createCanvas(windowWidth, windowHeight);
    angleMode(DEGREES);
    flyCount=10;





    dataServer = new PubNub({
        publish_key: pubKey,
        subscribe_key: subKey
      });
    
      dataServer.addListener({ message: readIncoming });
    
      dataServer.subscribe({ channels: [channelName] });



      
    }


    function readIncoming(inMessage) {
        
        publishedFlyCount = publishedFlyCount + parseInt(inMessage.message.publishedFlyCount);
      }




function draw() {
    background("black");
let r = random(18, 20)
translate(windowWidth/4, windowHeight/4)

    for (let i = 0; i < flyCount-publishedFlyCount; i++) {

    image(firefly, 80*i, r*i , 100, 80 );
    }


    fill(255, 255, 255);
  textSize(20);
  text('Fly Count : ' + publishedFlyCount, 0,0);
}