let beeimg;
 function preload(){
     beeimg = loadImage('assets/firefly.png');
 }

function Particle(x,y) {




    this.pos = createVector(x, y);
    this.vel = p5.Vector.random2D(0, 50);
    this.vel.setMag(random(2,5));
    this.acc = createVector(0, 1);


    this.update = function(){
      this.pos.add (this.vel);
      this.vel.add (this.acc);
    }


    this.show = function () {
        stroke(255);
        strokeWeight(6);
        point(this.pos.x, this.pos.y);

        //image(beeimg, this.pos.x, this.pos.y , 20, 18 );
    }

    this.attracted = function(target){
        var force = p5.Vector.sub(target, this.pos);
        var dsquared = force. magSq();
        dsquared = constrain(dsquared , 400, 450);
        var G = 50;
        var strength = G / dsquared;
        force.setMag(strength);
        this.acc = force;
    }
}