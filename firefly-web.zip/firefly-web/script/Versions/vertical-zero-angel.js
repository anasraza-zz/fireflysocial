let dataServer;
let pubKey = "pub-c-a89113e6-3093-4b43-8f4a-e1dce36bb107";
let subKey = "sub-c-7f74413c-3b65-11ec-8182-fea14ba1eb2b";
let channelName = "fireflySocial";








let firefly;
let flyNetImg;
let flyban;



let leftToRight_degrees;
let beebuzz, tada;
let beeXloc, vol;
let flynetsize = 250;
var flyNet = {
    img: 0,
    x: 0,
    y: 0,
    w: flynetsize,
    h: flynetsize * 1.81
};

let imgAngle = 0;

let flyCount = 0;
let flycount_inc = 0;
var dis = 0;

var flyingspeed = 5;
var fireflyXpos, fireflyYpos;

var xoff1 = 0;
var xoff2 = 100;


let r = flyNet.h;
let x1, x2, y1, y2, d1, d2, d3, dsum = 0;

function preload() {

    firefly = loadImage('/assets/firefly.png');
    flyNet.img = loadImage('/assets/vectorNet.png');
    beebuzz = loadSound('/assets/beebuzz.mp3');
    tada = loadSound('/assets/tada.mp3');
    flyban = loadImage('/assets/flyban.png');
}



function setup() {
    createCanvas(windowWidth, windowHeight);
    angleMode(DEGREES);

    // beebuzz.playMode("sustain");





    dataServer = new PubNub({
        publish_key: pubKey,
        subscribe_key: subKey
    });



    dataServer.subscribe({ channels: [channelName] });







}









function draw() {
    background("black");
    fill(255);




    flycount_inc = 0;



    fireflyXpos = map(noise(xoff1), 0, 1, 0, width + 100);
    fireflyYpos = map(noise(xoff2), 0, 1, 0, height - 300);
    xoff1 += 0.05;
    xoff2 += 0.05;



    flyingspeed = flyingspeed + 1;

    if (flyingspeed > width + 100) {
        flyingspeed = random(-200, -1000);
    }


    imgAngle = 88 + rotationY;





    push();

    translate(windowWidth - flyNet.w, windowHeight);

    rotate(rotationY);
    var flynetOffset = map(accelerationX, 0, 5, 0, 30)
    image(flyNet.img, 0, (-flynetOffset - flyNet.h), flyNet.w, flyNet.h);

    pop();




    push();

    x1 = r * cos(imgAngle) + windowWidth - flyNet.w;
    y1 = r * sin(imgAngle) + windowHeight;

    x2 = windowWidth - flyNet.w - r * cos(imgAngle) + 20;
    y2 = windowHeight - r * sin(imgAngle) + 20 - flynetOffset;


    x3 = x2 + flyNet.h * 0.34 * cos(imgAngle);
    y3 = y2 + flyNet.h * 0.34 * sin(imgAngle);


    stroke(255);
    strokeWeight(5);
    line(x2, y2, x3, y3);

    pop();

    d1 = dist(fireflyXpos + flyingspeed, fireflyYpos, x2, y2);
    d2 = dist(fireflyXpos + flyingspeed, fireflyYpos, x3, y3);
    d3 = int(dist(x2, y2, x3, y3)) + 50;
    dsum = int(d1 + d2);





    if (dsum < 205) {


        caught();
        noLoop();
        setTimeout(loop, 3000);




    }



    flyCount = flyCount + flycount_inc;



    image(firefly, fireflyXpos + flyingspeed, fireflyYpos, 100, 80);




    beeXloc = fireflyXpos + flyingspeed;

    vol = map(beeXloc, 0, windowWidth / 2, 0, 1);
    beebuzz.setVolume(vol);

    if (!beebuzz.isPlaying() && beeXloc >= -50 && beeXloc <= windowWidth + 50) {


        beebuzz.play();


    }
    if (beeXloc < -50 || beeXloc > windowWidth) {
        beebuzz.stop();

    }






    fill(255, 255, 255);
    textSize(12);

    text('H ' + windowHeight, 10, 20);
    text('W ' + windowWidth, 10, 40);



    text('Fly Count : ' + flyCount, 10, windowHeight - 20);

    text('X : ' + x1, 10, windowHeight - 40);
    text('Y : ' + y1, 10, windowHeight - 60);

    text('Rotation Y : ' + imgAngle, 10, windowHeight - 80);

    text('D1 : ' + d1, 10, windowHeight - 100);
    text('D2 : ' + d2, 10, windowHeight - 120);
    text('D3 : ' + d3, 10, windowHeight - 140);

    text('D sum : ' + dsum, 10, windowHeight - 160);

    text('flyingspeed : ' + flyingspeed, 10, windowHeight - 180);

    text('B X loc : ' + beeXloc, 10, windowHeight - 200);

    text('Vol5: ' + vol, 10, windowHeight - 220);







}





function caught() {

    image(flyban, 0, 0, windowWidth, windowHeight);

    tada.play();


    navigator.vibrate = navigator.vibrate || navigator.webkitVibrate || navigator.mozVibrate || navigator.msVibrate;

    if (navigator.vibrate) {

        navigator.vibrate(100);
    }

    flycount_inc = 1;
    flyingspeed = -500;



    dataServer.publish({
        channel: channelName,
        message: {
            publishedFlyCount: 1
        }
    });

}
















function getAccel() {
    DeviceMotionEvent.requestPermission().then(response => {
        if (response == 'granted') {
            // Add a listener to get smartphone orientation 
            // in the alpha-beta-gamma axes (units in degrees)
            window.addEventListener('deviceorientation', (event) => {
                // Expose each orientation angle in a more readable way
                rotation_degrees = event.alpha;
                frontToBack_degrees = event.beta;
                leftToRight_degrees = event.gamma;


                text('Roration Iphone ' + leftToRight_degrees, 10, windowHeight - 240);
            });
        }
    });
}











