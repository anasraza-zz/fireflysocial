let dataServer;
let pubKey = "pub-c-a89113e6-3093-4b43-8f4a-e1dce36bb107";
let subKey = "sub-c-7f74413c-3b65-11ec-8182-fea14ba1eb2b";
let channelName = "fireflySocial";

let publishedFlyCount = 0;


let fireflies = [];
let fireflyimg;


function preload() {
    fireflyimg = loadImage('assets/firefly.png');
}

function setup() {
    createCanvas(windowWidth, windowHeight);
    for(let i = 0; i<50; i++){

        let x = random(width);
        let y = random(height);
        fireflies[i] = new Firefly(x, y, 20);
    }



    dataServer = new PubNub({
        publish_key: pubKey,
        subscribe_key: subKey
      });
    
      dataServer.addListener({ message: readIncoming });
    
      dataServer.subscribe({ channels: [channelName] });



      
    }


    function readIncoming(inMessage) {
        
        publishedFlyCount = publishedFlyCount + parseInt(inMessage.message.publishedFlyCount);
        
      }






function draw() {

    background(0);

    var totalFireflies = fireflies.length - publishedFlyCount;

    for (let i =0; i<totalFireflies; i++){
        fireflies[i].move();
        fireflies[i].show();
        
    }

    navigator.vibrate(100);
    
    fill(255, 255, 255);
    textSize(20);
    text('Fly Count : ' + totalFireflies, 20,30);
    

}

class Firefly {

    constructor(x, y, r) {
        this.x = x;
        this.y = y;
        this.r = r;

    }

    move() {
        this.x = this.x + random(5, -5);
        this.y = this.y + random(5, -5);

        if(this.x > windowWidth-50  ){
            this.x = this.x + random (-100, -10);
        }
        if(this.x < 10 ){
            this.x = this.x + random (10, 50);
        }
        if(this.y > windowHeight-100 ){
            this.y = this.y + random(-5, -50);
        }

        if( this.y < 10){
            this.y = this.y + random(5, 10);
        }
    }

    show() {
        // stroke(255);
        // strokeWeight(4);
        // noFill();
        // ellipse(this.x, this.y, this.r * 2);
        image(fireflyimg, this.x, this.y, 60, 50 );

    }

}