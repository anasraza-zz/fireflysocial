var attractor;
var particles= [];
function setup() {
    createCanvas(windowWidth, windowHeight)

    for (var i =0; i<50 ; i++)
    {

        particles.push (new Particle(200, 100));
    }
    
    attractor = createVector(200, 200);
    

   
}


function draw(){
    background(0);
stroke(255)
strokeWeight(10);
point(attractor.x  , attractor.y);

for (var i =0; i<50 ; i++)
{

var particle = particles[i];
particle.attracted(attractor);
particle.update();
particle.show();
}

}