let handleNet;
let firefly;
let flyingspeed =0;
let imgAngle =0;

let flyCount =0;
let flycount_inc = 0;

let fireflyXpos = 0;
let fireflyYpos =0;


let hNetXpos = 0;
let hNetYpos = 0;


let r = 500;
let x= 0;
let y =0;
function preload() {
  handleNet = loadImage('assets/handle-net.png');
  firefly = loadImage('assets/firefly.png');
  }
 


function setup() {
  createCanvas(windowWidth, windowHeight);
  angleMode(DEGREES);
 
 
  }


  
  function draw() {
  background("black");

  fill(255, 255, 255);
  textSize(20);

  text('H ' + windowHeight, 10, 20);
  text('W ' + windowWidth, 10, 40);

  text('Fly Count : ' + flyCount, 10, windowHeight-20);
 



  text('X : ' + (x+hNetXpos) , 10, windowHeight-140);
  text('Y : ' + (y+hNetYpos)  , 10, windowHeight-120);


  text('hNetXpos : ' + hNetXpos , 10, windowHeight-160);
  text('hNetYpos : ' + hNetYpos  , 10, windowHeight-180);


  
  

  fireflyXpos = windowWidth - flyingspeed;
  fireflyYpos = random(50,55);





  image(firefly, fireflyXpos, fireflyYpos , 100, 80 );
  flyingspeed = flyingspeed + 1;

  if(flyingspeed>windowWidth+100){
    flyingspeed=random(-200, -900);
  }



 

  






  if(fireflyXpos > (x+hNetXpos)-50 && fireflyXpos < (x+hNetXpos)+150 && fireflyYpos > (y+hNetYpos)-40 && fireflyYpos < (y+hNetYpos)+150)
  {

    flycount_inc =1;
    flyingspeed = 500;
    flyCount = flyCount + flycount_inc;
  
  }


  text('fireflyXpos : ' + fireflyXpos , 10, windowHeight-60);
  text('fireflyYpos : ' + fireflyYpos , 10, windowHeight-80);










hNetXpos = windowWidth-200;
hNetYpos = windowHeight+50 - map(accelerationX, 0, 5,0, 30);


  translate(hNetXpos, hNetYpos );
  imgAngle = 290 + rotationY;
 
  x= r* cos(imgAngle);
  y= r* sin(imgAngle);
  
push();
  rotate(imgAngle);
  image(handleNet, 0, 0, 500, 250 );

pop();

fill(204, 101, 192, 127);
ellipse(x+40, y+40, 80, 80);





  }