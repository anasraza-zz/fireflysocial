let handleNet;
let firefly;
let flyingspeed =0;
let imgAngle =0;
let flyCount =0;

let fireflyXpos = 0;
let fireflyYpos =0;


let hNetXpos = 0;
let hNetYpos = 0;

function preload() {
  handleNet = loadImage('assets/handle-net.png');
  firefly = loadImage('assets/firefly.png');
  }
 


function setup() {
  createCanvas(windowWidth, windowHeight);
  angleMode(DEGREES);
 
 
  }


  
  function draw() {
  background("black");

  fill(255, 255, 255);
  textSize(20);
  text('Fly Count : ' + flyCount, 10, windowHeight-20);
  text('distance : ' , 10, windowHeight-60);

  text('fireflyXpos : ' + fireflyXpos , 10, windowHeight-80);
  text('fireflyYpos : ' + fireflyYpos , 10, windowHeight-100);

  text('hNetXpos : ' + hNetXpos , 10, windowHeight-120);
  text('hNetYpos : ' + hNetYpos  , 10, windowHeight-140);
 

  fireflyXpos = windowWidth -flyingspeed;
  fireflyYpos = random(50,55);


  image(firefly, fireflyXpos, fireflyYpos , 100, 80 );
  flyingspeed = flyingspeed + random (0, 10);



  if(flyingspeed>windowWidth){
    flyingspeed=random(-200, -900);
  }


hNetXpos = windowWidth-200;
hNetYpos = windowHeight+100 - map(accelerationX, 0, 5,0, 30);

  translate(hNetXpos, hNetYpos );
  rotate(290+rotationY);
  image(handleNet, 0, 0, 500, 250 );
  


  






  }